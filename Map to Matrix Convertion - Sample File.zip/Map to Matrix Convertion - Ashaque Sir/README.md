# README – AOI Matrix Workflow (GEE + Colab)

This workflow generates an Area of Interest (AOI) matrix raster and converts it into a labeled text file with latitude and longitude coordinates.

---

## Step 1. Upload AOI shapefile to Google Earth Engine (GEE)
1. Go to [Google Earth Engine Code Editor](https://code.earthengine.google.com).
2. Upload your AOI shapefile (e.g., Japan_SHP) to your GEE Assets.

---

## Step 2. Run the GEE Script
1. Copy the provided `GEE_AOI_Matrix.js` script into the GEE Code Editor.
2. Update the following parameters at the top of the script:
   - **AOI asset path** → your uploaded shapefile
   - **Pixel size (SCALE_M)** → e.g., `3000` for 3 km
   - **Output folder and file name** → choose your Google Drive folder/name
3. Run the script.  
   ✅ Output: A `.tif` raster (GeoTIFF) file will be saved to your Google Drive.

---

## Step 3. Run the Google Colab Script
1. Open [Google Colab](https://colab.research.google.com).
2. Copy the provided `Colab_Write_Matrix.py` script into a new notebook cell.
3. Update the parameters at the top:
   - **`input_path`** → the path to the `.tif` exported from GEE  
   - **`output_path`** → where the `.txt` matrix should be saved  
   - **`label_every_n_cols`** → adjust how often longitude labels appear (default = 10)
4. Run the script.  
   ✅ Output: A `.txt` file with the AOI matrix and coordinate labels.

---

## Done!
You now have:
- A GeoTIFF raster from GEE  
- A labeled text matrix from Colab  

---

## Support
For any questions, troubleshooting, or inquiries, please contact:

**Mashrup Hasan**  
📞 Phone: +880 1616-367984  
✉️ Email: [mashruphasan@gmail.com](mailto:mashruphasan@gmail.com)
